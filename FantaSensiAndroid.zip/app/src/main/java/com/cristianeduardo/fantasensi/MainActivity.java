package com.cristianeduardo.fantasensi;

import android.app.*;
import android.os.*;
import android.provider.Settings;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    TextView info;
    String maker, model, profile;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        maker=android.os.Build.MANUFACTURER;
        model=android.os.Build.MODEL;
        profile=detect(maker);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,32,24,24); root.setBackgroundColor(Color.rgb(17,17,17));
        TextView title=new TextView(this); title.setText("FANTA SENSI"); title.setTextColor(Color.WHITE); title.setTextSize(25); title.setTypeface(null,1);
        TextView handle=new TextView(this); handle.setText("@cristianeduardocr7  •  v1.0.0"); handle.setTextColor(0xffaaaaaa);
        info=new TextView(this); info.setTextColor(Color.WHITE); info.setTextSize(14); info.setPadding(0,24,0,24);
        info.setText("Fabricante: "+maker+"\nModelo: "+model+"\nPerfil automático: "+profile+"\nAndroid: "+Build.VERSION.RELEASE);
        Button grant=new Button(this); grant.setText("AUTORIZAR PAINEL FLUTUANTE");
        grant.setOnClickListener(v->{ if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:"+getPackageName())); startActivity(i);} else startOverlay(); });
        Button start=new Button(this); start.setText("INICIAR / ABRIR PAINEL");
        start.setOnClickListener(v->{if(Settings.canDrawOverlays(this)) startOverlay(); else Toast.makeText(this,"Autorize a sobreposição primeiro.",Toast.LENGTH_LONG).show();});
        TextView note=new TextView(this); note.setTextColor(0xffaaaaaa); note.setTextSize(12); note.setPadding(0,18,0,0);
        note.setText("O perfil do fabricante é selecionado automaticamente. O Android exige autorização explícita para exibir sobreposições. Recursos de mira/FPS/antivírus são apenas controles demonstrativos e não modificam jogos nem fazem varredura de segurança.");
        root.addView(title); root.addView(handle); root.addView(info); root.addView(grant); root.addView(start); root.addView(note); setContentView(root);
    }
    String detect(String m){
        String s=m.toLowerCase();
        if(s.contains("samsung")) return "Samsung / One UI";
        if(s.contains("xiaomi")||s.contains("redmi")||s.contains("poco")) return "Xiaomi / Redmi / POCO";
        if(s.contains("motorola")||s.contains("lenovo")) return "Motorola / Lenovo";
        if(s.contains("infinix")) return "Infinix";
        if(s.contains("tecno")) return "TECNO";
        if(s.contains("oppo")||s.contains("realme")||s.contains("oneplus")) return "OPPO / realme / OnePlus";
        if(s.contains("vivo")||s.contains("iqoo")) return "vivo / iQOO";
        if(s.contains("google")) return "Google Pixel";
        return "Android genérico (perfil compatível)";
    }
    void startOverlay(){ startService(new Intent(this,OverlayService.class)); Toast.makeText(this,"FANTA SENSI iniciado.",Toast.LENGTH_SHORT).show(); }
    @Override protected void onResume(){super.onResume(); if(info!=null) info.setText("Fabricante: "+maker+"\nModelo: "+model+"\nPerfil automático: "+profile+"\nAndroid: "+Build.VERSION.RELEASE+"\nSobreposição: "+(Settings.canDrawOverlays(this)?"autorizada":"não autorizada"));}
}
