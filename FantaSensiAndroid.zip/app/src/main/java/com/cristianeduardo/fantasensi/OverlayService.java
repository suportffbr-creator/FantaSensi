package com.cristianeduardo.fantasensi;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class OverlayService extends Service {
    WindowManager wm; View panel; WindowManager.LayoutParams params; LinearLayout body, tabs; String current="HEADTRICK"; boolean minimized=false;
    final int BG=0xff1b1b1b, SUR=0xff303030, RED=0xffc62828, WHITE=0xffeeeeee, MUTED=0xffaaaaaa;
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onCreate(){super.onCreate(); if(!Settings.canDrawOverlays(this)){stopSelf();return;} wm=(WindowManager)getSystemService(WINDOW_SERVICE); build(); }
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(12,10,12,10);return t;}
    GradientDrawable bg(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(8);d.setStroke(1,0xff4a4a4a);return d;}
    void build(){
      LinearLayout shell=new LinearLayout(this);shell.setOrientation(1);shell.setBackground(bg(BG));shell.setElevation(12);
      LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(8,4,8,4);
      TextView logo=text("FANTA SENSI",14,WHITE);logo.setTypeface(null,1);header.addView(logo,new LinearLayout.LayoutParams(0,-2,1));
      Button min=new Button(this);min.setText("━");min.setTextSize(12);min.setOnClickListener(v->{minimized=!minimized;tabs.setVisibility(minimized?View.GONE:View.VISIBLE);body.setVisibility(minimized?View.GONE:View.VISIBLE);});header.addView(min);
      Button close=new Button(this);close.setText("🚪");close.setOnClickListener(v->stopSelf());header.addView(close);
      shell.addView(header);
      tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);
      for(String tab:new String[]{"HEADTRICK","SECURITY","INFORMATION"}){Button b=new Button(this);b.setText(tab);b.setTextSize(9);b.setTextColor(WHITE);b.setOnClickListener(v->{current=tab;render();});tabs.addView(b,new LinearLayout.LayoutParams(0,48,1));}
      shell.addView(tabs);
      body=new LinearLayout(this);body.setOrientation(1);body.setPadding(8,4,8,8);shell.addView(body);panel=shell;
      params=new WindowManager.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*.88),WindowManager.LayoutParams.WRAP_CONTENT,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
      params.gravity=Gravity.TOP|Gravity.END;params.x=8;params.y=70;wm.addView(panel,params);render();
    }
    void row(String name,String desc){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(5,4,5,4);box.setBackground(bg(SUR));TextView t=text(name,13,WHITE);t.setTypeface(null,1);box.addView(t);if(desc!=null)box.addView(text(desc,10,MUTED));Switch sw=new Switch(this);sw.setText("Ativar / desativar");sw.setTextColor(WHITE);box.addView(sw);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=6;body.addView(box,lp);}
    void render(){body.removeAllViews();if(current.equals("HEADTRICK")){body.addView(text("HEADTRICK",11,RED));row("Regular mira","Ajuste visual demonstrativo; não controla a mira do jogo.");SeekBar seek=new SeekBar(this);seek.setMax(100);seek.setProgress(50);body.addView(seek);row("Auxílio VIP (precisão avançada)","Controle demonstrativo.");row("240 FPS","Não desbloqueia FPS acima do limite do aparelho ou jogo.");row("Reduzir travamentos","Não altera processos do jogo ou do sistema.");}
      else if(current.equals("SECURITY")){body.addView(text("SECURITY",11,RED));row("Otimização secreta","Indicador demonstrativo; não modifica o Android.");row("ANTI VIRUS","Indicador visual protegido/desprotegido. Não é antivírus real.");row("Escudo ✓","Indicador visual de nível de proteção; não oferece segurança adicional.");}
      else{body.addView(text("INFORMATION",11,RED));body.addView(text("FANTA SENSI\n@cristianeduardocr7\nVersão 1.0.0\nFabricante: "+Build.MANUFACTURER+"\nModelo: "+Build.MODEL+"\nPerfil: adaptado automaticamente\n\nPainel Android nativo. Permissões especiais dependem do fabricante e da versão do Android.",12,WHITE));}
    }
    @Override public void onDestroy(){if(wm!=null&&panel!=null)try{wm.removeView(panel);}catch(Exception ignored){}super.onDestroy();}
}
