FANTA SENSI — projeto Android nativo

COMO GERAR O APK PELO FLUXO TERMUX + GITHUB ACTIONS
A compilação Android completa não é confiável diretamente no Termux porque as ferramentas oficiais de build do Android são feitas para Linux/Windows/macOS, não Android. Este projeto usa GitHub Actions (compilação em nuvem) e você inicia o envio pelo Termux.

1) Crie um repositório vazio no GitHub chamado FantaSensi (sem README).
2) No Termux, instale:
   pkg update -y && pkg install git gh -y
3) Faça login:
   gh auth login
4) Extraia este ZIP em ~/storage/downloads/FantaSensiAndroid e execute:
   cd ~/storage/downloads/FantaSensiAndroid
   git init
   git add .
   git commit -m "FANTA SENSI Android"
   gh repo create FantaSensi --public --source=. --remote=origin --push
   (Se já criou o repositório manualmente, use: git remote add origin https://github.com/SEU_USUARIO/FantaSensi.git && git branch -M main && git push -u origin main)
5) Acesse o repositório no GitHub > Actions > Build FANTA SENSI APK.
6) Quando terminar, abra a execução e baixe o artefato FANTA-SENSI-APK.

O APK é um protótipo nativo com detecção do fabricante/modelo e painel flutuante após autorização do usuário.
A sobreposição precisa de autorização manual do Android. Não é possível contornar as proteções do sistema.
Não implementa gatilho Bluetooth + captura de tela nem bloqueio de gravação; isso exige integração adicional e permissões compatíveis.
Os controles de mira, FPS, antivírus e otimização são demonstrativos e não modificam jogos nem fazem varredura real.
Não existe proteção absoluta contra engenharia reversa.
